# Azure Resource Manager Templates
Azure Resource Manager Templates for the Marketplace.

### Instructions for Testing
- Click this button
<a href="https://portal.azure.com/#create/Microsoft.Template" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
- Click edit.
- Copy the contents of mainTemplate.json to the template window.
- Fill in required parameters.
- Hit Create.
