# Deploy a Puppet Enterprise Master VM

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fpuppetlabs%2Fazure-image%2Fmaster%2FmainTemplate.json" target="_blank"><img src="http://azuredeploy.net/deploybutton.png"/></a>
<a href="http://armviz.io/#/?load=https%3A%2F%2Fraw.githubusercontent.com%2FAzure%2Fgregohardy%2Fpuppetlabs%2Fmaster%2FmainTemplate.json" target="_blank"><img src="http://armviz.io/visualizebutton.png"/></a>


This template launches a Puppet Enterprise Master VM.

This template contains extra parameters to allow for the existing resources use cases, which is a common scenario for Solution Templates in the Azure Marketplace.

